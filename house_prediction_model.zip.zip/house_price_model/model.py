import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
import pickle

# Load dataset
data = pd.read_csv('house_data.csv')

# Encode categorical features
label_encoder_location = LabelEncoder()
label_encoder_condition = LabelEncoder()
label_encoder_garage = LabelEncoder()

# Apply label encoding
data['Location'] = label_encoder_location.fit_transform(data['Location'])
data['Condition'] = label_encoder_condition.fit_transform(data['Condition'])
data['Garage'] = label_encoder_garage.fit_transform(data['Garage'])

# Define features and target
X = data[['Area', 'Bedrooms', 'Bathrooms', 'Floors', 'YearBuilt', 'Location', 'Condition', 'Garage']]
y = data['Price']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train model
model = LinearRegression()
model.fit(X_train_scaled, y_train)

# Save model and encoders
pickle.dump(model, open('model.pkl', 'wb'))
pickle.dump(scaler, open('scaler.pkl', 'wb'))
pickle.dump(label_encoder_location, open('label_encoder_location.pkl', 'wb'))
pickle.dump(label_encoder_condition, open('label_encoder_condition.pkl', 'wb'))
pickle.dump(label_encoder_garage, open('label_encoder_garage.pkl', 'wb'))

print("Model training complete and saved successfully!")