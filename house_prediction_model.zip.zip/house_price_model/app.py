from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

# Load model and encoders
model = pickle.load(open('model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))
label_encoder_location = pickle.load(open('label_encoder_location.pkl', 'rb'))
label_encoder_condition = pickle.load(open('label_encoder_condition.pkl', 'rb'))
label_encoder_garage = pickle.load(open('label_encoder_garage.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        area = float(request.form['area'])
        bedrooms = int(request.form['bedrooms'])
        bathrooms = int(request.form['bathrooms'])
        floors = int(request.form['floors'])
        year_built = int(request.form['year_built'])
        location = request.form['location']
        condition = request.form['condition']
        garage = request.form['garage']

        # Encode categorical values
        location_encoded = label_encoder_location.transform([location])[0]
        condition_encoded = label_encoder_condition.transform([condition])[0]
        garage_encoded = label_encoder_garage.transform([garage])[0]

        # Create input array
        input_arr = np.array([[area, bedrooms, bathrooms, floors, year_built, location_encoded, condition_encoded, garage_encoded]])
        input_scaled = scaler.transform(input_arr)

        # Predict
        pred = model.predict(input_scaled)[0]
        return render_template('index.html', prediction_text=f"Predicted House Price: ₹{pred:,.2f}")

    except Exception as e:
        return render_template('index.html', prediction_text=f"Error: {str(e)}")

if __name__ == '_main_':
    app.run(debug=True)